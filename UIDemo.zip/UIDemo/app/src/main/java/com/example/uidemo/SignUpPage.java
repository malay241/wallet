package com.example.uidemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SignUpPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);
    }
}