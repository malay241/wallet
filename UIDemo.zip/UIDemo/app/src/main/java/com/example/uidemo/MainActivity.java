package com.example.uidemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText email, password;
    public void loginButtonClicked(View view){
        email = findViewById(R.id.login_email);
        password = findViewById(R.id.password);

        if(validateLogin(email.getText().toString(), password.getText().toString())){
            Intent intent = new Intent(this,HomePage.class );
            startActivity(intent);
        }
    }

    public void editTextClicked(View view){
        email = email = findViewById(R.id.login_email);
        password = findViewById(R.id.password);
        String emailString = email.getText().toString();
        String passwordString = password.getText().toString();

    }


    public void signUpButtonClicked(View view){
        Intent intent = new Intent(this, SignUpPage.class);
        startActivity(intent);
    }

    public boolean validateLogin(String login_email, String login_password){

        if(login_email.trim().equals("") || login_password.trim().equals("") ){
            Toast.makeText(this, "Fields can't be left empty! Please fill in the fields.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(login_email).matches()) {
            Toast.makeText(this, "Invalid Email! Re-enter.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(login_email.equals("admin@gmail.com")&& login_password.equals("admin@1234")){
            return true;
        }
        else{
            Toast.makeText(this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}